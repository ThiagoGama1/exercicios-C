/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void bubbleSort(int *vetor, int n){
    int temp, flagTroca;
    
    do{
        flagTroca = 0;
        for(int i = 0; i < n - 1; i++){
            if(vetor[i] > vetor[i+1]){
                temp = vetor[i];
                vetor[i] = vetor[i+1];
                vetor[i+1] = temp;
                flagTroca = 1;
            }
        }
        
    }while(flagTroca);
        printf("Vetor ordenado: ");
    for(int k = 0; k < n; k++){
            
            printf("%d", k);
        }
    
    /*
    for(int i = 0; i < tamanho; i++){
        for(int j = i + 1; j < tamanho - 1; j++){
            if(vetor[i] > vetor[j]){
                temp = vetor[j];
                vetor[j] = vetor[i];
                vetor[i] = temp;
            }
        }
    }
    */
    
}


int main()
{
    int vetor[] = {0,2,3,1,4,5,6,9,10,8};
    int n = sizeof(vetor) / sizeof(vetor[0]);
    bubbleSort(vetor, n);
    
  

    return 0;
}

/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int buscaOrdenada(int *vetor, int numero, int tamanho){
    int i, j;
    
    for(i = 0; i < tamanho; i++){
        if(vetor[i] == numero){
            return i;
        }
        else if(vetor[i] > numero){
            break;
        }
       
        
    }
    
    return -1;
}

int main()
{
    int N;
    printf("Informe um numero: ");
    scanf("%d", &N);
    int vetor[10] = {0,1,2,3,4,5,6,7,8,9};
    int tamanho = sizeof(vetor) / sizeof(vetor[0]);
    int x = buscaOrdenada(vetor, N, tamanho);
    if(x == -1){
        printf("Valor não encontrado");
        
    }
    else{
        printf("Numero %d encontrado na posição %d", N, x);
    }
    return 0;
}
